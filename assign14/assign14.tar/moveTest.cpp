#include "move.h"
/**********************************************************************
 * MAIN: Driver program
 ***********************************************************************/
int main()
{
   char board[8][8] =
   {
      { 'r', 'n', 'b', 'q', 'k', 'b', 'n', 'r' },
      { 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p' },
      { NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE,
        NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE },
      { NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE,
        NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE },
      { NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE,
        NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE },
      { NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE,
        NO_PIECE, NO_PIECE, NO_PIECE, NO_PIECE },
      { 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P' },
      { 'R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R' }
   };
   
   // forever
   for (;;)
   {
      Move move;

      // prompt
      cout << "What is the move? ";
      cin  >> move.text;
      if (move.text == string("quit"))
         return 0;

      // parse
      try
      {
         moveParse(move, board);

         // verify
         cout << "\tSource:       ("
              << (int)move.source.c << ", " << (int)move.source.r
              << ")\n";
         cout << "\tDestination:  ("
              << (int)move.dest.c << ", " << (int)move.dest.r
              << ")\n";
         cout << "\tCapture?      "
           << (move.capture ? "yes" : "no")
           << endl;
         cout << "\tKing Castle?  "
              << (move.castleK ? "yes" : "no")
              << endl;
         cout << "\tQueen Castle? "
              << (move.castleQ ? "yes" : "no")
              << endl;
         cout << "\tPromote?      "
              << (move.promote ? "yes" : "no")
              << endl;
         cout << "\tEn Passant?   "
              << (move.enpassant ? "yes" : "no")
              << endl;
         cout << "\tPiece:        "
              << move.piece
              << endl;
      }
      catch (string s)
      {
         cout << "ERROR: " << s << endl;
      }
   }
   
   return 0;
}